def print_calculations(sum_result, difference, product, quotient):
    print(f"The sum is: {sum_result}")
    print(f"The difference is: {difference}")
    print(f"The product is: {product}")
    print(f"The quotient is: {quotient}")
