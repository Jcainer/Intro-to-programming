def calculator(number1, number2):
    sum_result = number1 + number2
    difference = number1 - number2
    product = number1 * number2
    quotient = number1 / number2
    return sum_result, difference, product, quotient
