def file_handling(sum_result, difference, product, quotient):
    with open("calculations.txt", "a+") as file:
        file.write(f"The sum is: {sum_result}\n")
        file.write(f"The difference is: {difference}\n")
        file.write(f"The product is: {product}\n")
        file.write(f"The quotient is: {quotient}\n")
