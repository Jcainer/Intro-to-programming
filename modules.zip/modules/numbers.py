def numbers():
    number1 = float(input("Enter number 1: "))
    number2 = float(input("Enter number 2: "))
    return number1, number2
