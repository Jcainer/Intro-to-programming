from numbers_module import numbers
from Calculator import calculator
from output import print_calculations
from file_handler import file_handling

def main():
    num1, num2 = numbers()
    results = calculator(num1, num2)
    sum_result, difference, product, quotient = results
    print_calculations(sum_result, difference, product, quotient)
    file_handling(sum_result, difference, product, quotient)

if __name__ == "__main__":
    main()
